<?php 
$koneksi = mysqli_connect("localhost", "root", "", "portofolio_silvi");